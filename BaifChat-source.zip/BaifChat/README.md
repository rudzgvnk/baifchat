# BaifChat — Flutter starter

Prototype UI for BaifChat with an iPhone-inspired Liquid Glass look (translucent panels, blur, soft gradients).
This starter currently uses demo/local messages only. Firebase authentication and real-time chat are the next development step.

## Requirements
- Flutter SDK (stable)
- Android SDK / Android Studio, or a cloud Flutter build service
- For Android builds: `flutter doctor` should be mostly green

## Run
```bash
flutter pub get
flutter run
```

## Build APK
```bash
flutter build apk --release
```
APK output:
`build/app/outputs/flutter-apk/app-release.apk`

## Next step: real chat
This UI starter does NOT yet send messages to other devices. To enable real accounts and real-time messaging, configure a Firebase project and add `firebase_core`, `firebase_auth`, and `cloud_firestore`, then implement authentication and Firestore security rules. Never put service-account private keys in the app.
