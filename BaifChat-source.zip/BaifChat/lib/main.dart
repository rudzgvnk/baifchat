import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() => runApp(const BaifChatApp());

const Color ink = Color(0xFF090A12);
const Color violet = Color(0xFF9A7BFF);
const Color cyan = Color(0xFF78E6F5);
const Color whiteSoft = Color(0xFFF4F2FF);

class BaifChatApp extends StatelessWidget {
  const BaifChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BaifChat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: ink,
        colorScheme: ColorScheme.fromSeed(
          seedColor: violet,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const WelcomeScreen(),
    );
  }
}

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _register = false;
  bool _showPassword = false;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  void _continue() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GlassBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 28),
                  Center(
                    child: Container(
                      width: 92,
                      height: 92,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFFB7A5FF), violet, Color(0xFF5D49B8)],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: violet.withOpacity(.35),
                            blurRadius: 35,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: const Icon(CupertinoIcons.chat_bubble_2_fill,
                          color: Colors.white, size: 42),
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'BaifChat',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: whiteSoft,
                      fontSize: 35,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -.8,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Your conversations, in a softer light.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: whiteSoft.withOpacity(.65), fontSize: 14),
                  ),
                  const SizedBox(height: 34),
                  GlassPanel(
                    radius: 28,
                    padding: const EdgeInsets.all(22),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(
                          _register ? 'Create your account' : 'Welcome back',
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 7),
                        Text(
                          _register ? 'Start your BaifChat journey.' : 'Sign in to continue chatting.',
                          style: TextStyle(color: whiteSoft.withOpacity(.58), fontSize: 13),
                        ),
                        const SizedBox(height: 22),
                        _GlassTextField(
                          controller: _email,
                          hint: 'Email address',
                          icon: CupertinoIcons.mail,
                          keyboardType: TextInputType.emailAddress,
                        ),
                        const SizedBox(height: 12),
                        _GlassTextField(
                          controller: _password,
                          hint: 'Password',
                          icon: CupertinoIcons.lock,
                          obscureText: !_showPassword,
                          suffix: IconButton(
                            onPressed: () => setState(() => _showPassword = !_showPassword),
                            icon: Icon(
                              _showPassword ? CupertinoIcons.eye_slash : CupertinoIcons.eye,
                              color: whiteSoft.withOpacity(.65),
                              size: 19,
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        GradientButton(
                          label: _register ? 'Create account' : 'Sign in',
                          onTap: _continue,
                        ),
                        const SizedBox(height: 16),
                        TextButton(
                          onPressed: () => setState(() => _register = !_register),
                          child: Text(
                            _register ? 'Already have an account? Sign in' : 'New to BaifChat? Create account',
                            style: const TextStyle(color: Color(0xFFC7BBFF), fontSize: 13),
                          ),
                        ),
                        Text(
                          'Prototype preview • Login is not connected yet',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: whiteSoft.withOpacity(.35), fontSize: 10),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),
                  Text(
                    'PRIVATE BY DESIGN  •  MADE FOR YOUR PEOPLE',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: whiteSoft.withOpacity(.35),
                      fontSize: 9,
                      letterSpacing: 1.8,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  final List<ChatPreview> chats = const [
    ChatPreview('Naya', 'Oke, nanti kabarin ya ✨', 'Now', 'N', Color(0xFFE3A7D7), 2, true),
    ChatPreview('Raka', 'Wkwkwk siap 😂', '2m', 'R', Color(0xFF8D9DFF), 0, true),
    ChatPreview('BaifChat Team', 'Mira: welcome semuanya!', '12m', 'B', Color(0xFF8AD9D1), 4, false),
    ChatPreview('Alya', 'Foto yang tadi bagus banget', '1h', 'A', Color(0xFFFFC58C), 0, false),
    ChatPreview('Dimas', 'Gas main sore ini?', '3h', 'D', Color(0xFFB6A2FF), 0, false),
  ];

  @override
  Widget build(BuildContext context) {
    return GlassBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 18),
                child: Row(
                  children: [
                    Container(
                      height: 46,
                      width: 46,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        gradient: const LinearGradient(colors: [violet, Color(0xFF5A4BBD)]),
                      ),
                      child: const Icon(CupertinoIcons.chat_bubble_2_fill, color: Colors.white),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('BaifChat', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, letterSpacing: -.5)),
                          Text('Good conversations start here', style: TextStyle(fontSize: 11, color: Colors.white54)),
                        ],
                      ),
                    ),
                    GlassIconButton(icon: CupertinoIcons.qrcode_viewfinder, onTap: () => _notice('QR friends coming soon')),
                    const SizedBox(width: 8),
                    GlassIconButton(icon: CupertinoIcons.plus, onTap: () => _notice('New chat coming soon')),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: _GlassTextField(
                  hint: 'Search conversations',
                  icon: CupertinoIcons.search,
                  onChanged: (_) {},
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                height: 92,
                child: ListView(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  scrollDirection: Axis.horizontal,
                  children: const [
                    _StoryBubble(label: 'Your story', initials: '+', color: violet, add: true),
                    _StoryBubble(label: 'Naya', initials: 'N', color: Color(0xFFE3A7D7), online: true),
                    _StoryBubble(label: 'Raka', initials: 'R', color: Color(0xFF8D9DFF), online: true),
                    _StoryBubble(label: 'Alya', initials: 'A', color: Color(0xFFFFC58C)),
                    _StoryBubble(label: 'Dimas', initials: 'D', color: Color(0xFFB6A2FF)),
                    _StoryBubble(label: 'Mira', initials: 'M', color: Color(0xFF8AD9D1), online: true),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(22, 10, 22, 12),
                child: Row(
                  children: [
                    const Text('Messages', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
                    const Spacer(),
                    Text('See all', style: TextStyle(color: violet.withOpacity(.95), fontSize: 12, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  itemCount: chats.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 9),
                  itemBuilder: (context, index) {
                    final chat = chats[index];
                    return GlassPanel(
                      radius: 22,
                      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 13),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => ChatScreen(chat: chat)),
                        ),
                        child: Row(
                          children: [
                            _Avatar(initials: chat.initials, color: chat.color, online: chat.online, size: 51),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(chat.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                                  const SizedBox(height: 5),
                                  Text(chat.message, maxLines: 1, overflow: TextOverflow.ellipsis,
                                    style: TextStyle(color: whiteSoft.withOpacity(.57), fontSize: 12)),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(chat.time, style: TextStyle(color: whiteSoft.withOpacity(.42), fontSize: 10)),
                                const SizedBox(height: 8),
                                if (chat.unread > 0)
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                                    decoration: const BoxDecoration(color: violet, shape: BoxShape.circle),
                                    child: Text('${chat.unread}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
          child: GlassPanel(
            radius: 25,
            padding: const EdgeInsets.symmetric(vertical: 9),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _NavItem(icon: CupertinoIcons.chat_bubble_2_fill, label: 'Chats', selected: _tab == 0, onTap: () => setState(() => _tab = 0)),
                _NavItem(icon: CupertinoIcons.person_2, label: 'Friends', selected: _tab == 1, onTap: () => _notice('Friends page coming soon')),
                _NavItem(icon: CupertinoIcons.circle_grid_3x3, label: 'Discover', selected: _tab == 2, onTap: () => _notice('Discover coming soon')),
                _NavItem(icon: CupertinoIcons.person_crop_circle, label: 'Profile', selected: _tab == 3, onTap: () => _notice('Profile coming soon')),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _notice(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message),
      behavior: SnackBarBehavior.floating,
      backgroundColor: const Color(0xFF29253A),
    ));
  }
}

class ChatScreen extends StatefulWidget {
  final ChatPreview chat;
  const ChatScreen({super.key, required this.chat});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final List<ChatMessage> _messages = [
    const ChatMessage('Hey! Apa kabar?', false, '10:41'),
    const ChatMessage('Baik nih, lu gimana?', true, '10:42'),
    const ChatMessage('Aman juga. Lagi nyobain BaifChat 😄', false, '10:42'),
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _send() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    setState(() => _messages.add(ChatMessage(text, true, 'Now')));
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    return GlassBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          titleSpacing: 0,
          title: Row(
            children: [
              _Avatar(initials: widget.chat.initials, color: widget.chat.color, online: widget.chat.online, size: 39),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.chat.name, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                  Text(widget.chat.online ? 'Online' : 'Last seen recently',
                    style: TextStyle(fontSize: 10, color: widget.chat.online ? const Color(0xFF8EE5B2) : Colors.white54)),
                ],
              ),
            ],
          ),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(CupertinoIcons.phone)),
            IconButton(onPressed: () {}, icon: const Icon(CupertinoIcons.ellipsis)),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 20),
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final message = _messages[index];
                  return Align(
                    alignment: message.mine ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
                      margin: const EdgeInsets.only(bottom: 11),
                      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 11),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(19),
                          topRight: const Radius.circular(19),
                          bottomLeft: Radius.circular(message.mine ? 19 : 5),
                          bottomRight: Radius.circular(message.mine ? 5 : 19),
                        ),
                        gradient: message.mine
                            ? const LinearGradient(colors: [Color(0xFF9C82FF), Color(0xFF6654C7)])
                            : null,
                        color: message.mine ? null : Colors.white.withOpacity(.085),
                        border: Border.all(color: Colors.white.withOpacity(.12)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Align(alignment: Alignment.centerLeft, child: Text(message.text, style: const TextStyle(fontSize: 14, height: 1.35))),
                          const SizedBox(height: 5),
                          Text(message.time, style: TextStyle(fontSize: 9, color: Colors.white.withOpacity(.6))),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 14),
              child: Row(
                children: [
                  GlassIconButton(icon: CupertinoIcons.plus, onTap: () {}),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _GlassTextField(
                      controller: _controller,
                      hint: 'Write a message...',
                      onSubmitted: (_) => _send(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: _send,
                    child: Container(
                      height: 49,
                      width: 49,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(17),
                        gradient: const LinearGradient(colors: [Color(0xFFB8A6FF), violet, Color(0xFF6854C9)]),
                        boxShadow: [BoxShadow(color: violet.withOpacity(.25), blurRadius: 15)],
                      ),
                      child: const Icon(CupertinoIcons.arrow_up, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ChatPreview {
  final String name, message, time, initials;
  final Color color;
  final int unread;
  final bool online;
  const ChatPreview(this.name, this.message, this.time, this.initials, this.color, this.unread, this.online);
}

class ChatMessage {
  final String text, time;
  final bool mine;
  const ChatMessage(this.text, this.mine, this.time);
}

class GlassBackground extends StatelessWidget {
  final Widget child;
  const GlassBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        const Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(color: ink))),
        Positioned(top: -110, left: -70, child: _GlowBlob(size: 300, color: violet.withOpacity(.27))),
        Positioned(top: 240, right: -120, child: _GlowBlob(size: 290, color: cyan.withOpacity(.12))),
        Positioned(bottom: -160, left: 20, child: _GlowBlob(size: 310, color: const Color(0xFF6B4BDB).withOpacity(.22))),
        child,
      ],
    );
  }
}

class _GlowBlob extends StatelessWidget {
  final double size;
  final Color color;
  const _GlowBlob({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, color: color),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 70, sigmaY: 70),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }
}

class GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  const GlassPanel({super.key, required this.child, this.padding = const EdgeInsets.all(12), this.radius = 24});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.075),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: Colors.white.withOpacity(.15), width: 1),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.white.withOpacity(.11), Colors.white.withOpacity(.035)],
            ),
          ),
          child: child,
        ),
      ),
    );
  }
}

class _GlassTextField extends StatelessWidget {
  final TextEditingController? controller;
  final String hint;
  final IconData? icon;
  final Widget? suffix;
  final bool obscureText;
  final TextInputType? keyboardType;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;

  const _GlassTextField({
    this.controller,
    required this.hint,
    this.icon,
    this.suffix,
    this.obscureText = false,
    this.keyboardType,
    this.onChanged,
    this.onSubmitted,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(17),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.055),
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: Colors.white.withOpacity(.12)),
          ),
          child: TextField(
            controller: controller,
            obscureText: obscureText,
            keyboardType: keyboardType,
            onChanged: onChanged,
            onSubmitted: onSubmitted,
            style: const TextStyle(fontSize: 13, color: whiteSoft),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: whiteSoft.withOpacity(.38), fontSize: 13),
              prefixIcon: icon == null ? null : Icon(icon, size: 18, color: whiteSoft.withOpacity(.5)),
              suffixIcon: suffix,
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 16),
            ),
          ),
        ),
      ),
    );
  }
}

class GradientButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const GradientButton({super.key, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 52,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(17),
          gradient: const LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: [Color(0xFFB5A2FF), Color(0xFF8B71F2), Color(0xFF6852C6)],
          ),
          boxShadow: [BoxShadow(color: violet.withOpacity(.25), blurRadius: 20, offset: const Offset(0, 7))],
        ),
        child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
      ),
    );
  }
}

class GlassIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const GlassIconButton({super.key, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: GlassPanel(
        radius: 15,
        padding: const EdgeInsets.all(11),
        child: Icon(icon, size: 18, color: whiteSoft),
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  final String initials;
  final Color color;
  final bool online;
  final double size;
  const _Avatar({required this.initials, required this.color, this.online = false, this.size = 48});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          width: size,
          height: size,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [color, color.withOpacity(.55)],
            ),
            border: Border.all(color: Colors.white.withOpacity(.25), width: 1.2),
          ),
          child: Text(initials, style: TextStyle(color: ink, fontWeight: FontWeight.w800, fontSize: size * .34)),
        ),
        if (online)
          Positioned(
            bottom: 0,
            right: 0,
            child: Container(
              width: size * .25,
              height: size * .25,
              decoration: BoxDecoration(
                color: const Color(0xFF7EE3A9),
                shape: BoxShape.circle,
                border: Border.all(color: ink, width: 2),
              ),
            ),
          ),
      ],
    );
  }
}

class _StoryBubble extends StatelessWidget {
  final String label, initials;
  final Color color;
  final bool add, online;
  const _StoryBubble({required this.label, required this.initials, required this.color, this.add = false, this.online = false});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 70,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: add ? Colors.white24 : violet.withOpacity(.8), width: 1.5),
            ),
            child: _Avatar(initials: initials, color: color, online: online, size: 48),
          ),
          const SizedBox(height: 6),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 10, color: whiteSoft.withOpacity(.72))),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _NavItem({required this.icon, required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: selected ? violet.withOpacity(.2) : Colors.transparent,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 19, color: selected ? const Color(0xFFD2C7FF) : Colors.white54),
            const SizedBox(height: 3),
            Text(label, style: TextStyle(fontSize: 9, color: selected ? const Color(0xFFD2C7FF) : Colors.white54)),
          ],
        ),
      ),
    );
  }
}
